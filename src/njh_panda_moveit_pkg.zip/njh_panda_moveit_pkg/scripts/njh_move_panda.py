#!/usr/bin/env python

import rospy
import sys
import tf
import math
from math import pi
from scipy.spatial.transform import Rotation as R
import numpy as np
from geometry_msgs.msg import Pose
import moveit_commander
from moveit_commander import MoveGroupCommander, roscpp_initialize
from vision_msgs.msg import Detection3DArray
from symbolic_msgs.srv import*

def get_vision():
    rospy.wait_for_service('add_two_ints')
    target_pose = Pose()

    try:
        get_bbox_3d = rospy.ServiceProxy('perception_command', perception)

        #request
        detect_obj = bool(input('detect_obj : '))
        place = int(input('place : '))

        resp1 = get_bbox_3d(detect_obj, place)

        print("get_bbox_3d : " resp1)

        det_3d = Detection3DArray()
        det_3d = resp1.det_3d

        target_pose.position.x = det_3d.detections[0]
        
    except rospy.ServiceException as e:
        print ("Service Call Failed : %s" %e)

def move_panda():
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('njh_move_panda_node', anonymous=True)


    group = MoveGroupCommander("arm")  #관절 그룹에 대한 인터페이스
    group.set_pose_reference_frame("panda_link0")

    current_pose = group.get_current_pose()
    print("Current pose : ", current_pose)


    group.set_pose_target()

    

